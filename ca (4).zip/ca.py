# NumPy Questions
import numpy as np
import pandas as pd
df=pd.read_csv("ca.csv")
# NumPy Questions


# NumPy Questions
import numpy as np

# 1. Create a NumPy array of retail sales and compute the mean.
retail_sales = df['RETAIL SALES'].fillna(0).to_numpy()
mean_sales = np.mean(retail_sales)
print("Mean Retail Sales:", mean_sales)

# 2. Find the maximum warehouse sales using NumPy.
warehouse_sales = df['WAREHOUSE SALES'].fillna(0).to_numpy()
max_warehouse_sales = np.max(warehouse_sales)
print("Max Warehouse Sales:", max_warehouse_sales)

# 3. Compute the standard deviation of retail transfers.
retail_transfers = df['RETAIL TRANSFERS'].fillna(0).to_numpy()
std_retail_transfers = np.std(retail_transfers)
print("Std Dev of Retail Transfers:", std_retail_transfers)

# 4. Find unique item types using NumPy.
unique_item_types = np.unique(df['ITEM TYPE'].dropna().to_numpy())
print("Unique Item Types:", unique_item_types)

# 5. Normalize the retail sales column.
norm_retail_sales = (retail_sales - np.min(retail_sales)) / (np.max(retail_sales) - np.min(retail_sales))
print("Normalized Retail Sales:", norm_retail_sales[:5])

# 6. Count non-zero retail sales entries.
non_zero_sales = np.count_nonzero(retail_sales)
print("Non-zero Retail Sales Count:", non_zero_sales)

# 7. Compute the median of warehouse sales.
median_warehouse_sales = np.median(warehouse_sales)
print("Median Warehouse Sales:", median_warehouse_sales)

# 8. Create a boolean mask for items with sales above the mean.
high_sales_mask = retail_sales > mean_sales
print("High Sales Mask:", high_sales_mask[:5])

# 9. Compute the correlation coefficient between retail and warehouse sales.
corr_coeff = np.corrcoef(retail_sales, warehouse_sales)[0, 1]
print("Correlation Coefficient:", corr_coeff)

# 10. Reshape retail sales into a 2D array (if possible).
reshaped_sales = retail_sales[:100].reshape(10, 10)
print("Reshaped Retail Sales:", reshaped_sales)


# Pandas Questions

# 1. Find the total retail sales per year.
total_sales_per_year = df.groupby('YEAR')['RETAIL SALES'].sum()
print(total_sales_per_year)

# 2. Count the number of unique suppliers.
num_unique_suppliers = df['SUPPLIER'].nunique()
print("Number of Unique Suppliers:", num_unique_suppliers)

# 3. Find the item with the highest warehouse sales.
highest_warehouse_sales = df.loc[df['WAREHOUSE SALES'].idxmax(), 'ITEM DESCRIPTION']
print("Item with Highest Warehouse Sales:", highest_warehouse_sales)

# 4. Filter all wine items.
wine_items = df[df['ITEM TYPE'] == 'WINE']
print(wine_items.head())

# 5. Compute the average retail sales per item type.
avg_sales_per_type = df.groupby('ITEM TYPE')['RETAIL SALES'].mean()
print(avg_sales_per_type)

# 6. Identify the supplier with the most items.
supplier_most_items = df['SUPPLIER'].value_counts().idxmax()
print("Supplier with Most Items:", supplier_most_items)

# 7. Find the month with the highest total sales.
df['TOTAL SALES'] = df['RETAIL SALES'] + df['WAREHOUSE SALES']
highest_sales_month = df.groupby('MONTH')['TOTAL SALES'].sum().idxmax()
print("Month with Highest Sales:", highest_sales_month)

# 8. Create a pivot table of sales by item type and year.
sales_pivot = df.pivot_table(values='RETAIL SALES', index='ITEM TYPE', columns='YEAR', aggfunc='sum')
print(sales_pivot)

# 9. Find all suppliers who sold beer.
beer_suppliers = df[df['ITEM TYPE'] == 'BEER']['SUPPLIER'].unique()
print("Suppliers Selling Beer:", beer_suppliers)

# 10. Sort the dataset by warehouse sales in descending order.
df_sorted = df.sort_values(by='WAREHOUSE SALES', ascending=False)
print(df_sorted.head())


# Matplotlib Questions
import matplotlib.pyplot as plt

# 1. Plot total sales per year.
total_sales_per_year.plot(kind='bar', title='Total Sales per Year')
plt.show()

# 2. Create a histogram of retail sales.
plt.hist(retail_sales, bins=30)
plt.title('Retail Sales Distribution')
plt.show()

# 3. Plot a line graph of total sales per month.
df.groupby('MONTH')['TOTAL SALES'].sum().plot(kind='line', title='Total Sales per Month')
plt.show()

# 4. Compare warehouse vs. retail sales using a scatter plot.
plt.scatter(df['RETAIL SALES'], df['WAREHOUSE SALES'], alpha=0.5)
plt.xlabel('Retail Sales')
plt.ylabel('Warehouse Sales')
plt.title('Retail vs. Warehouse Sales')
plt.show()

# 5. Create a pie chart for sales by item type.
sales_by_item = df.groupby('ITEM TYPE')['TOTAL SALES'].sum()
sales_by_item = sales_by_item[sales_by_item > 0]  # Remove negative values

sales_by_item.plot(kind='pie', autopct='%1.1f%%', startangle=90, figsize=(8, 8))
plt.ylabel('')  # Remove default y-label
plt.title('Sales by Item Type')
plt.show()

# 6. Plot a boxplot of retail sales.
plt.boxplot(retail_sales)
plt.title('Boxplot of Retail Sales')
plt.show()


# Seaborn Questions
import seaborn as sns

# 1. Create a violin plot for warehouse sales.
sns.violinplot(x=df['WAREHOUSE SALES'])
plt.title('Warehouse Sales Distribution')
plt.show()

# 2. Create a heatmap of sales correlation.
sns.heatmap(df[['RETAIL SALES', 'WAREHOUSE SALES', 'RETAIL TRANSFERS']].corr(), annot=True, cmap='coolwarm')
plt.title('Sales Correlation Heatmap')
plt.show()

# 3. Create a bar plot for total sales by item type.
sns.barplot(x='ITEM TYPE', y='TOTAL SALES', data=df)
plt.xticks(rotation=90)
plt.title('Total Sales by Item Type')
plt.show()


# 4. Create a count plot for item types.
sns.countplot(x='ITEM TYPE', data=df)
plt.xticks(rotation=90)
plt.title('Count of Items by Type')
plt.show()

# 5. Create a box plot of retail sales per item type.
sns.boxplot(x='ITEM TYPE', y='RETAIL SALES', data=df)
plt.xticks(rotation=90)
plt.title('Box Plot of Retail Sales by Item Type')
plt.show()
